<?php
/**
 * Plugin Name: NOAH Customer Account Hub
 * Description: Seller/Buyer dashboard, selling requests, notifications, returns & item details.
 * Version:     5.1 (Rebuilt & Fixed)
 * Requires PHP: 7.4
 * Author:      NOAH
 */

if (!defined('ABSPATH')) exit;

/* ============================================================
   0. DEPENDENCY CHECK
   ============================================================ */
add_action('plugins_loaded', function () {
    if (!class_exists('WooCommerce')) {
        add_action('admin_notices', function () {
            echo '<div class="notice notice-error"><p><strong>NOAH Customer Account Hub</strong> requires WooCommerce to be active.</p></div>';
        });
        return;
    }
    noah_hub_check_post_types();
});

/* ============================================================
   1. POST TYPES + GUARD
   ============================================================ */
add_action('init', function () {
    register_post_type('noah_sell_lead', [
        'label'     => 'Sell Leads',
        'public'    => false,
        'show_ui'   => true,
        'supports'  => ['title', 'thumbnail'],
        'menu_icon' => 'dashicons-tag',
    ]);
    register_post_type('noah_consignment', [
        'label'     => 'Consignments',
        'public'    => false,
        'show_ui'   => true,
        'supports'  => ['title', 'thumbnail'],
        'menu_icon' => 'dashicons-archive',
    ]);
    register_post_type('noah_notification', [
        'label'    => 'Notifications',
        'public'   => false,
        'show_ui'  => false,
        'supports' => ['title'],
    ]);
});

function noah_hub_check_post_types() {
    if (!post_type_exists('noah_consignment') || !post_type_exists('noah_sell_lead')) {
        add_action('admin_notices', function () {
            echo '<div class="notice notice-error"><p>NOAH Hub: post types noah_consignment / noah_sell_lead are missing!</p></div>';
        });
    }
}

/* ============================================================
   2. ENDPOINT REGISTRATION
   ============================================================ */
add_filter('woocommerce_account_endpoints', function ($endpoints) {
    $endpoints['noah-dashboard']        = 'Dashboard';
    $endpoints['noah-selling-requests'] = 'Selling Requests';
    $endpoints['noah-notifications']    = 'Notifications';
    $endpoints['noah-returns']          = 'Returns & Pickup';
    $endpoints['noah-item-details']     = 'Item Details';
    return $endpoints;
});

add_action('init', function () {
    foreach (['noah-dashboard', 'noah-selling-requests', 'noah-notifications', 'noah-returns', 'noah-item-details'] as $ep) {
        add_rewrite_endpoint($ep, EP_PAGES);
    }
});

/* ============================================================
   3. ACTIVATION
   ============================================================ */
register_activation_hook(__FILE__, function () {
    foreach (['noah-dashboard', 'noah-selling-requests', 'noah-notifications', 'noah-returns', 'noah-item-details'] as $ep) {
        add_rewrite_endpoint($ep, EP_PAGES);
    }
    flush_rewrite_rules();
});

/* ============================================================
   4. HELPERS
   ============================================================ */
function noah_hub_current_user_role_view() {
    $view = isset($_GET['view']) ? sanitize_key($_GET['view']) : '';
    if (!in_array($view, ['buyer', 'seller'], true)) {
        $view = '';
    }
    if (!$view) {
        $is_seller = get_user_meta(get_current_user_id(), 'noah_is_seller', true);
        $view = $is_seller ? 'seller' : 'buyer';
    }
    return $view;
}

function noah_hub_get_user_items($user_id, $limit = -1) {
    $user = get_userdata($user_id);
    $email = strtolower(trim($user ? $user->user_email : ''));
    if (!$email) return [];

    $leads = get_posts([
        'post_type'   => 'noah_sell_lead',
        'post_status' => 'publish',
        'numberposts' => $limit,
        'meta_query'  => [['key' => '_noah_lead_email', 'value' => $email, 'compare' => '=']],
    ]);
    $consignments = get_posts([
        'post_type'   => 'noah_consignment',
        'post_status' => 'publish',
        'numberposts' => $limit,
        'meta_query'  => [['key' => '_noah_owner_email', 'value' => $email, 'compare' => '=']],
    ]);
    return array_merge($leads, $consignments);
}

function noah_hub_get_status($item) {
    if ($item->post_type === 'noah_consignment') {
        return get_post_meta($item->ID, '_noah_consignment_status', true) ?: 'received';
    }
    $converted = get_post_meta($item->ID, '_noah_lead_converted_product_id', true);
    return $converted ? 'approved' : 'pending';
}

function noah_hub_status_badge($status) {
    $map = [
        'pending'   => ['Pending Valuation', 'noah-badge--amber'],
        'received'  => ['Received',          'noah-badge--amber'],
        'valuation' => ['In Valuation',      'noah-badge--blue'],
        'approved'  => ['Approved',          'noah-badge--green'],
        'paid'      => ['Paid',              'noah-badge--green'],
        'rejected'  => ['Rejected',          'noah-badge--red'],
    ];
    list($label, $class) = $map[$status] ?? ['Pending', 'noah-badge--amber'];
    return '<span class="noah-badge ' . esc_attr($class) . '">' . esc_html($label) . '</span>';
}

function noah_hub_item_ref($item) {
    return 'NOAH-' . date_i18n('Y', strtotime($item->post_date)) . '-' . str_pad((string) $item->ID, 4, '0', STR_PAD_LEFT);
}

function noah_hub_item_title($item) {
    $pid = get_post_meta($item->ID, '_linked_product_id', true) ?: get_post_meta($item->ID, '_noah_lead_converted_product_id', true);
    return $pid ? get_the_title($pid) : ($item->post_title ?: 'Untitled Item');
}

function noah_hub_details_url($item_id) {
    return esc_url(wc_get_account_endpoint_url('noah-item-details') . '?item=' . intval($item_id));
}

function noah_hub_safe_link($link) {
    $link = esc_url_raw($link);
    if ($link && strpos($link, home_url()) === 0) {
        return $link;
    }
    return '';
}

/* ============================================================
   5. NOTIFICATIONS
   ============================================================ */
function noah_hub_add_notification($user_id, $title, $body, $link = '') {
    wp_insert_post([
        'post_type'   => 'noah_notification',
        'post_status' => 'publish',
        'post_title'  => $title,
        'post_author' => $user_id,
        'meta_input'  => [
            'body'    => $body,
            'link'    => noah_hub_safe_link($link),
            'is_read' => 0,
            'user_id' => $user_id,
            'type'    => 'info',
        ],
    ]);
}

function noah_hub_get_notifications($user_id) {
    return get_posts([
        'post_type'   => 'noah_notification',
        'post_status' => 'publish',
        'numberposts' => 50,
        'author'      => $user_id,
        'meta_key'    => 'user_id',
        'meta_value'  => $user_id,
        'orderby'     => 'date',
        'order'       => 'DESC',
    ]);
}

function noah_hub_mark_read($notif_id, $user_id) {
    if (intval(get_post_meta($notif_id, 'user_id', true)) === intval($user_id)) {
        update_post_meta($notif_id, 'is_read', 1);
    }
}

add_action('template_redirect', function () {
    if (!is_account_page() || !is_user_logged_in()) return;
    $user_id = get_current_user_id();

    if (isset($_GET['mark_read'], $_GET['_wpnonce']) && wp_verify_nonce($_GET['_wpnonce'], 'noah_mark_read')) {
        noah_hub_mark_read(intval($_GET['mark_read']), $user_id);
        wp_safe_redirect(remove_query_arg(['mark_read', '_wpnonce']));
        exit;
    }
    if (isset($_GET['mark_all'], $_GET['_wpnonce']) && wp_verify_nonce($_GET['_wpnonce'], 'noah_mark_all')) {
        foreach (noah_hub_get_notifications($user_id) as $n) {
            if (!get_post_meta($n->ID, 'is_read', true)) noah_hub_mark_read($n->ID, $user_id);
        }
        wp_safe_redirect(remove_query_arg(['mark_all', '_wpnonce']));
        exit;
    }
});

/* ============================================================
   6. MY ACCOUNT MENU
   ============================================================ */
add_filter('woocommerce_account_menu_items', function ($items) {
    $new = [];
    foreach ($items as $key => $label) {
        $new[$key] = $label;
        if ($key === 'dashboard') {
            $new['noah-dashboard']        = 'Dashboard';
            $new['noah-selling-requests'] = 'Selling Requests';
            $new['noah-notifications']    = 'Notifications';
            $new['noah-returns']          = 'Returns & Pickup';
        }
    }
    return $new;
}, 20);

add_filter('woocommerce_account_menu_item_classes', function ($classes, $endpoint) {
    if ($endpoint === 'noah-dashboard') $classes[] = 'noah-menu-highlight';
    return $classes;
}, 10, 2);

/* ============================================================
   7. SHARED STYLES
   ============================================================ */
add_action('wp_head', function () {
    if (!is_account_page()) return;
    ?>
    <style>
        :root{--noah-dark:#111114;--noah-gold:#d4a939;--noah-gold-2:#b8912e;--noah-bg:#f5f5f3;
        --noah-card:#ffffff;--noah-border:#e6e6e2;--noah-text:#2b2b28;--noah-muted:#8a8a85;
        --noah-green:#2e7d46;--noah-green-bg:#e6f4ea;--noah-amber:#a97a12;--noah-amber-bg:#fdf4e0;
        --noah-blue:#22568c;--noah-blue-bg:#e8f0fa;--noah-red:#a33;--noah-red-bg:#fbe9e9;
        --noah-radius:14px;}
        .woocommerce-MyAccount-content{max-width:1080px;}
        .noah-page-title{font-size:26px;font-weight:700;color:var(--noah-text);margin:0 0 6px;}
        .noah-page-sub{color:var(--noah-muted);font-size:14px;margin:0 0 26px;}
        .noah-role-switch{display:flex;gap:8px;margin-bottom:22px;}
        .noah-role-switch a{padding:8px 18px;border-radius:999px;font-size:13px;font-weight:600;
        text-decoration:none;color:var(--noah-muted);background:var(--noah-card);border:1px solid var(--noah-border);}
        .noah-role-switch a.active{background:var(--noah-dark);color:#fff;border-color:var(--noah-dark);}
        .noah-menu-highlight a{color:var(--noah-gold) !important;font-weight:700;}
        .noah-card{background:var(--noah-card);border:1px solid var(--noah-border);border-radius:var(--noah-radius);
        padding:24px;margin-bottom:20px;box-shadow:0 1px 2px rgba(0,0,0,.03);}
        .noah-card h3{margin:0 0 4px;font-size:17px;color:var(--noah-text);}
        .noah-card .sub{color:var(--noah-muted);font-size:13px;margin:0 0 18px;}
        table.noah-table{width:100%;border-collapse:collapse;font-size:14px;}
        table.noah-table th{text-align:left;color:var(--noah-muted);font-weight:600;font-size:12px;
        text-transform:uppercase;letter-spacing:.04em;padding:10px 12px;border-bottom:2px solid var(--noah-border);}
        table.noah-table td{padding:14px 12px;border-bottom:1px solid var(--noah-border);color:var(--noah-text);vertical-align:middle;}
        .noah-thumb{width:52px;height:52px;border-radius:10px;object-fit:cover;background:#eee;}
        .noah-ref{font-size:12px;color:var(--noah-muted);font-family:monospace;}
        .noah-link{color:var(--noah-gold-2);font-weight:600;text-decoration:none;font-size:13px;}
        .noah-link:hover{text-decoration:underline;}
        .noah-badge{display:inline-block;padding:4px 12px;border-radius:999px;font-size:12px;font-weight:600;}
        .noah-badge--green{background:var(--noah-green-bg);color:var(--noah-green);}
        .noah-badge--amber{background:var(--noah-amber-bg);color:var(--noah-amber);}
        .noah-badge--blue{background:var(--noah-blue-bg);color:var(--noah-blue);}
        .noah-badge--red{background:var(--noah-red-bg);color:var(--noah-red);}
        .noah-stat-row{display:grid;grid-template-columns:repeat(auto-fit,minmax(200px,1fr));gap:16px;margin-bottom:20px;}
        .noah-stat{background:var(--noah-card);border:1px solid var(--noah-border);border-radius:var(--noah-radius);padding:20px;}
        .noah-stat .label{color:var(--noah-muted);font-size:12px;text-transform:uppercase;letter-spacing:.05em;}
        .noah-stat .value{font-size:24px;font-weight:700;color:var(--noah-text);margin-top:6px;}
        .noah-empty{text-align:center;padding:48px 20px;color:var(--noah-muted);}
        .noah-empty .btn{display:inline-block;margin-top:16px;background:var(--noah-gold);color:#fff;
        padding:11px 26px;border-radius:999px;text-decoration:none;font-weight:600;font-size:14px;}
        .noah-notif{display:flex;gap:14px;align-items:flex-start;padding:16px;border:1px solid var(--noah-border);
        border-radius:12px;margin-bottom:10px;background:var(--noah-card);}
        .noah-notif.unread{background:#fffbef;border-color:#f0e2b6;}
        .noah-notif-dot{width:9px;height:9px;border-radius:50%;background:var(--noah-gold);margin-top:6px;flex-shrink:0;}
        .noah-notif-dot.read{background:#ddd;}
        .noah-notif-date{color:var(--noah-muted);font-size:12px;margin-top:3px;}
        .noah-breadcrumb{font-size:13px;color:var(--noah-muted);margin-bottom:18px;}
        .noah-breadcrumb a{color:var(--noah-gold-2);text-decoration:none;}
        .noah-details-grid{display:grid;grid-template-columns:1.05fr .95fr;gap:28px;align-items:start;}
        @media(max-width:800px){.noah-details-grid{grid-template-columns:1fr;}}
        .noah-gallery-hero{width:100%;aspect-ratio:1/1;border-radius:var(--noah-radius);object-fit:cover;background:#eee;}
        .noah-thumbs{display:flex;gap:10px;margin-top:12px;flex-wrap:wrap;}
        .noah-thumbs img{width:70px;height:70px;border-radius:10px;object-fit:cover;cursor:pointer;
        border:2px solid transparent;background:#eee;}
        .noah-thumbs img.sel{border-color:var(--noah-gold);}
        .noah-details-title{font-size:24px;font-weight:700;margin:0 0 4px;}
        .noah-details-meta{color:var(--noah-muted);font-size:13px;margin-bottom:14px;}
        .noah-desc{font-size:14px;color:var(--noah-text);line-height:1.7;}
        .noah-cert{display:flex;align-items:center;gap:12px;background:#fafaf8;border:1px solid var(--noah-border);
        border-radius:12px;padding:14px 16px;margin:18px 0;}
        .noah-cert .t{font-weight:700;font-size:14px;}
        .noah-cert .s{color:var(--noah-muted);font-size:12px;}
        .noah-attrs{display:grid;grid-template-columns:repeat(4,1fr);gap:10px;margin:18px 0;}
        @media(max-width:700px){.noah-attrs{grid-template-columns:repeat(2,1fr);}}
        .noah-attr{background:#fafaf8;border:1px solid var(--noah-border);border-radius:10px;padding:12px;text-align:center;}
        .noah-attr .k{font-size:11px;color:var(--noah-muted);text-transform:uppercase;letter-spacing:.04em;}
        .noah-attr .v{font-weight:700;font-size:14px;margin-top:4px;}
        .noah-specs{width:100%;border-collapse:collapse;font-size:14px;}
        .noah-specs td{padding:12px 6px;border-bottom:1px solid var(--noah-border);}
        .noah-specs td:first-child{color:var(--noah-muted);}
        .noah-specs td:last-child{text-align:right;font-weight:600;}
        .noah-payout{background:var(--noah-dark);color:#fff;border-radius:var(--noah-radius);padding:22px;margin:20px 0;}
        .noah-payout .row{display:flex;justify-content:space-between;padding:7px 0;font-size:14px;color:#cfcfc9;}
        .noah-payout .row.total{border-top:1px solid #33332e;margin-top:10px;padding-top:14px;
        font-size:17px;font-weight:700;color:#fff;}
        .noah-payout .row.total .amt{color:var(--noah-gold);}
        .noah-timeline{display:flex;margin:34px 0 10px;}
        .noah-step{flex:1;text-align:center;position:relative;}
        .noah-step::before{content:'';position:absolute;top:15px;left:-50%;width:100%;height:3px;background:#e2e2dd;z-index:0;}
        .noah-step:first-child::before{display:none;}
        .noah-step.done::before{background:var(--noah-gold);}
        .noah-dot{width:32px;height:32px;border-radius:50%;background:#fff;border:2px solid #d8d8d2;color:var(--noah-muted);
        display:inline-flex;align-items:center;justify-content:center;font-size:13px;font-weight:700;position:relative;z-index:1;}
        .noah-step.done .noah-dot{background:var(--noah-gold);border-color:var(--noah-gold);color:#fff;}
        .noah-step-label{font-size:12px;color:var(--noah-text);font-weight:600;margin-top:8px;}
        .noah-step:not(.done) .noah-step-label{color:var(--noah-muted);font-weight:400;}
    </style>
    <script>
    document.addEventListener('click', function (e) {
        if (e.target.matches('.noah-thumbs img')) {
            var hero = document.querySelector('.noah-gallery-hero');
            if (hero) { hero.src = e.target.dataset.full || e.target.src; }
            document.querySelectorAll('.noah-thumbs img').forEach(function (t) { t.classList.remove('sel'); });
            e.target.classList.add('sel');
        }
    });
    </script>
    <?php
});

/* ============================================================
   8. ENDPOINT RENDERERS
   ============================================================ */
add_action('woocommerce_account_noah-dashboard_endpoint', 'noah_render_dashboard');
add_action('woocommerce_account_noah-selling-requests_endpoint', 'noah_render_selling_requests');
add_action('woocommerce_account_noah-notifications_endpoint', 'noah_render_notifications');
add_action('woocommerce_account_noah-returns_endpoint', 'noah_render_returns');
add_action('woocommerce_account_noah-item-details_endpoint', 'noah_render_item_details');

/* ---------- DASHBOARD ---------- */
function noah_render_dashboard() {
    $user_id = get_current_user_id();
    if (!$user_id) return;
    $view = noah_hub_current_user_role_view();
    $items = noah_hub_get_user_items($user_id, 5);
    $unread = 0;
    foreach (noah_hub_get_notifications($user_id) as $n) {
        if (!get_post_meta($n->ID, 'is_read', true)) $unread++;
    }
    ?>
    <h1 class="noah-page-title">Welcome back, <?php echo esc_html(wp_get_current_user()->display_name); ?></h1>
    <p class="noah-page-sub">Here's what's happening with your account.</p>
    <div class="noah-role-switch">
        <a href="<?php echo esc_url(wc_get_account_endpoint_url('noah-dashboard')); ?>?view=buyer" class="<?php echo $view === 'buyer' ? 'active' : ''; ?>">Buyer</a>
        <a href="<?php echo esc_url(wc_get_account_endpoint_url('noah-dashboard')); ?>?view=seller" class="<?php echo $view === 'seller' ? 'active' : ''; ?>">Seller</a>
    </div>
    <div class="noah-stat-row">
        <div class="noah-stat"><div class="label">Active Consignments</div>
        <div class="value"><?php echo esc_html(count(array_filter($items, fn($i) => $i->post_type === 'noah_consignment'))); ?></div></div>
        <div class="noah-stat"><div class="label">Selling Requests</div>
        <div class="value"><?php echo esc_html(count($items)); ?></div></div>
        <div class="noah-stat"><div class="label">Unread Notifications</div>
        <div class="value"><?php echo esc_html($unread); ?></div></div>
    </div>
    <div class="noah-card">
        <h3>Recent Items</h3>
        <p class="sub">Your latest selling requests and consignments.</p>
        <?php noah_render_items_table($items); ?>
    </div>
    <?php
}

/* ---------- SELLING REQUESTS ---------- */
function noah_render_selling_requests() {
    $items = noah_hub_get_user_items(get_current_user_id(), -1);
    ?>
    <h1 class="noah-page-title">Selling Requests</h1>
    <p class="noah-page-sub">Track every item you've submitted to NOAH.</p>
    <div class="noah-card">
        <?php noah_render_items_table($items); ?>
    </div>
    <?php
}

function noah_render_items_table(array $items) {
    if (!$items) {
        echo '<div class="noah-empty"><p>You have no selling requests yet.</p>';
        echo '<a class="btn" href="' . esc_url(home_url('/sell-product-with-noah/')) . '">Sell Product With NOAH</a></div>';
        return;
    }
    echo '<table class="noah-table"><thead><tr>
    <th>Item</th><th>Reference</th><th>Date Submitted</th><th>Status</th><th></th></tr></thead><tbody>';
    foreach ($items as $it) {
        $thumb = get_the_post_thumbnail_url($it->ID, 'thumbnail') ?: wc_placeholder_img_src();
        printf(
            '<tr>
            <td><div style="display:flex;align-items:center;gap:12px;">
            <img class="noah-thumb" src="%s" alt="">
            <div><strong>%s</strong></div></div></td>
            <td><span class="noah-ref">%s</span></td>
            <td>%s</td>
            <td>%s</td>
            <td><a class="noah-link" href="%s">Details &rarr;</a></td>
            </tr>',
            esc_url($thumb),
            esc_html(noah_hub_item_title($it)),
            esc_html(noah_hub_item_ref($it)),
            esc_html(date_i18n('M j, Y', strtotime($it->post_date))),
            noah_hub_status_badge(noah_hub_get_status($it)),
            noah_hub_details_url($it->ID)
        );
    }
    echo '</tbody></table>';
}

/* ---------- NOTIFICATIONS ---------- */
function noah_render_notifications() {
    $user_id = get_current_user_id();
    $notifs = noah_hub_get_notifications($user_id);
    ?>
    <h1 class="noah-page-title">Notifications</h1>
    <p class="noah-page-sub">Updates about your items, valuations and payouts.</p>
    <a class="noah-link" style="display:inline-block;margin-bottom:16px;"
    href="<?php echo esc_url(add_query_arg('mark_all', '1', wp_nonce_url(wc_get_account_endpoint_url('noah-notifications'), 'noah_mark_all'))); ?>">
    Mark all as read</a>
    <?php if (!$notifs): ?>
        <div class="noah-empty"><p>You have no notifications yet.</p></div>
    <?php else: foreach ($notifs as $n):
        $is_read = (bool) get_post_meta($n->ID, 'is_read', true);
        $body    = get_post_meta($n->ID, 'body', true);
        $link    = noah_hub_safe_link(get_post_meta($n->ID, 'link', true));
        $mark_url = wp_nonce_url(
            add_query_arg('mark_read', $n->ID, wc_get_account_endpoint_url('noah-notifications')),
            'noah_mark_read'
        );
    ?>
    <div class="noah-notif <?php echo $is_read ? '' : 'unread'; ?>">
        <span class="noah-notif-dot <?php echo $is_read ? 'read' : ''; ?>"></span>
        <div style="flex:1;">
            <strong><?php echo esc_html($n->post_title); ?></strong>
            <div style="font-size:13px;color:var(--noah-muted);margin-top:2px;"><?php echo esc_html($body); ?></div>
            <div class="noah-notif-date"><?php echo esc_html(date_i18n('F j, Y \a\t g:i a', strtotime($n->post_date))); ?></div>
        </div>
        <div style="display:flex;gap:10px;align-items:center;">
            <?php if ($link): ?><a class="noah-link" href="<?php echo esc_url($link); ?>">View</a><?php endif; ?>
            <?php if (!$is_read): ?><a class="noah-link" href="<?php echo esc_url($mark_url); ?>">Mark read</a><?php endif; ?>
        </div>
    </div>
    <?php endforeach; endif;
}

/* ---------- RETURNS & PICKUP ---------- */
function noah_render_returns() {
    $user_id = get_current_user_id();
    $orders = wc_get_orders([
        'customer_id' => $user_id,
        'limit' => 20,
        'orderby' => 'date',
        'order' => 'DESC',
    ]);
    ?>
    <h1 class="noah-page-title">Returns & Pickup</h1>
    <p class="noah-page-sub">Request a return or schedule a pickup for one of your orders.</p>
    <div class="noah-card">
        <h3>Recent Orders</h3>
        <p class="sub">Only orders from the last 30 days are eligible for return.</p>
        <?php if (!$orders): ?>
            <div class="noah-empty"><p>You have no orders yet.</p></div>
        <?php else: ?>
        <table class="noah-table"><thead><tr>
        <th>Order</th><th>Date</th><th>Total</th><th>Status</th><th></th>
        </tr></thead><tbody>
        <?php foreach ($orders as $order):
            $created = $order->get_date_created();
            $age_days = $created ? (time() - $created->getTimestamp()) / DAY_IN_SECONDS : 999;
            $eligible = $age_days <= 30;
        ?>
        <tr>
            <td><strong>#<?php echo esc_html($order->get_order_number()); ?></strong></td>
            <td><?php echo $created ? esc_html(date_i18n('M j, Y', $created->getTimestamp())) : '—'; ?></td>
            <td><?php echo wp_kses_post($order->get_formatted_order_total()); ?></td>
            <td><?php echo esc_html(wc_get_order_status_name($order->get_status())); ?></td>
            <td>
                <?php echo $eligible ? '<span style="color:var(--noah-green);font-size:12px;">Eligible</span>' : '<span style="color:var(--noah-muted);font-size:12px;">Window Closed</span>'; ?>
                <a class="noah-link" href="<?php echo esc_url($order->get_view_order_url()); ?>" style="margin-left:10px;">View order</a>
            </td>
        </tr>
        <?php endforeach; ?>
        </tbody></table>
        <?php endif; ?>
    </div>
    <?php
}

/* ---------- ITEM DETAILS ---------- */
function noah_render_item_details() {
    $user_id = get_current_user_id();
    $item_id = isset($_GET['item']) ? absint($_GET['item']) : 0;
    $item = $item_id ? get_post($item_id) : null;

    if (!$item || !in_array($item->post_type, ['noah_sell_lead', 'noah_consignment'], true)) {
        echo '<div class="noah-empty"><p>Item not found.</p>
        <a class="btn" href="' . esc_url(wc_get_account_endpoint_url('noah-selling-requests')) . '">Back to Selling Requests</a></div>';
        return;
    }

    $email = strtolower(trim(get_userdata($user_id)->user_email ?? ''));
    $owner = $item->post_type === 'noah_consignment'
        ? get_post_meta($item->ID, '_noah_owner_email', true)
        : get_post_meta($item->ID, '_noah_lead_email', true);

    if (strtolower(trim((string) $owner)) !== $email) {
        echo '<div class="noah-empty"><p>Item not found.</p></div>';
        return;
    }

    $get = fn($key, $fallback = '—') => (get_post_meta($item->ID, $key, true) ?: $fallback);
    $title      = noah_hub_item_title($item);
    $ref        = noah_hub_item_ref($item);
    $status     = noah_hub_get_status($item);
    $category   = $get('_noah_item_category');
    $material   = $get('_noah_item');
    $desc       = get_post_meta($item->ID, '_noah_item_description', true) ?: $item->post_content;
    $purity     = $get('_noah_item_purity');
    $weight     = $get('_noah_item_weight');
    $color      = $get('_noah_item_color');
    $size       = $get('_noah_item_size');
    $jtype      = $get('_noah_item_type');
    $stone      = $get('_noah_item_stone');
    $stone_w    = $get('_noah_item_stone_weight');
    $stone_c    = $get('_noah_item_stone_color');
    $stone_cl   = $get('_noah_item_stone_clarity');
    $cert       = get_post_meta($item->ID, '_noah_item_certificate', true);
    $payout     = (float) get_post_meta($item->ID, '_noah_payout_total', true);
    $commission = (float) get_post_meta($item->ID, '_noah_commission', true);
    $fees       = (float) get_post_meta($item->ID, '_noah_fees', true);
    $valuation  = (float) get_post_meta($item->ID, '_noah_valuation', true);

    $gallery = [];
    if ($thumb = get_the_post_thumbnail_url($item->ID, 'large')) $gallery[] = $thumb;
    $extra = get_post_meta($item->ID, '_noah_item_gallery', true);
    if (is_string($extra)) $extra = array_filter(array_map('trim', explode(',', $extra)));
    foreach ((array) $extra as $gid) {
        if ($u = wp_get_attachment_image_url(absint($gid), 'large')) $gallery[] = $u;
    }
    if (!$gallery) $gallery[] = wc_placeholder_img_src('large');
    $hero = array_shift($gallery);
    $is_vid = (bool) get_post_meta($item->ID, '_noah_item_is_video', true);

    $flow = ['received', 'valuation', 'approved', 'payout'];
    $idx = array_search($status, $flow, true);
    if ($status === 'pending') $idx = 0;
    if ($idx === false) $idx = ($status === 'rejected') ? 1 : 0;
    ?>
    <div class="noah-breadcrumb">
        <a href="<?php echo esc_url(wc_get_account_endpoint_url('noah-dashboard')); ?>">Home</a> &nbsp;/&nbsp;
        <a href="<?php echo esc_url(wc_get_account_endpoint_url('noah-selling-requests')); ?>">Sell Precious Metals</a> &nbsp;/&nbsp;
        Product Details
    </div>
    <div class="noah-details-grid">
        <div>
            <?php if ($is_vid): ?>
                <video class="noah-gallery-hero" controls poster="<?php echo esc_url($hero); ?>"></video>
            <?php else: ?>
                <img class="noah-gallery-hero" src="<?php echo esc_url($hero); ?>" alt="<?php echo esc_attr($title); ?>">
            <?php endif; ?>
            <?php if ($gallery): ?>
            <div class="noah-thumbs">
                <?php foreach ($gallery as $u): ?>
                <img src="<?php echo esc_url($u); ?>" data-full="<?php echo esc_url($u); ?>" alt="">
                <?php endforeach; ?>
            </div>
            <?php endif; ?>
        </div>
        <div>
            <?php echo noah_hub_status_badge($status); ?>
            <h1 class="noah-details-title" style="margin-top:10px;"><?php echo esc_html($title); ?></h1>
            <div class="noah-details-meta">
                <span class="noah-ref" style="font-size:13px;"><?php echo esc_html($ref); ?></span>
                &nbsp;·&nbsp; <?php echo esc_html($category); ?> · <?php echo esc_html($material); ?>
            </div>
            <?php if ($desc): ?>
            <h3 style="font-size:15px;margin:14px 0 6px;">Description</h3>
            <div class="noah-desc"><?php echo wp_kses_post(wpautop($desc)); ?></div>
            <?php endif; ?>
            <?php if ($cert): ?>
            <div class="noah-cert">
                <span style="font-size:22px;">🛡️</span>
                <div>
                    <div class="t"><?php echo esc_html($cert); ?> Certified</div>
                    <div class="s">This item is accompanied by an official grading certificate.</div>
                </div>
            </div>
            <?php endif; ?>
            <div class="noah-attrs">
                <div class="noah-attr"><div class="k">Metal</div><div class="v"><?php echo esc_html($material); ?></div></div>
                <div class="noah-attr"><div class="k">Purity</div><div class="v"><?php echo esc_html($purity); ?></div></div>
                <div class="noah-attr"><div class="k">Weight</div><div class="v"><?php echo esc_html($weight); ?></div></div>
                <div class="noah-attr"><div class="k">Color</div><div class="v"><?php echo esc_html($color); ?></div></div>
            </div>
        </div>
    </div>
    <div class="noah-card">
        <h3>Technical Specifications</h3>
        <p class="sub">Full details of this item as registered at intake.</p>
        <table class="noah-specs">
            <tr><td>Product ID</td><td><?php echo esc_html($ref); ?></td></tr>
            <tr><td>Jewelry Type</td><td><?php echo esc_html($jtype); ?></td></tr>
            <tr><td>Material</td><td><?php echo esc_html($material); ?></td></tr>
            <tr><td>Gold Purity</td><td><?php echo esc_html($purity); ?></td></tr>
            <tr><td>Color</td><td><?php echo esc_html($color); ?></td></tr>
            <tr><td>Gross Weight</td><td><?php echo esc_html($weight); ?></td></tr>
            <tr><td>Size</td><td><?php echo esc_html($size); ?></td></tr>
            <tr><td>Stone</td><td><?php echo esc_html($stone); ?></td></tr>
            <tr><td>Stone Weight</td><td><?php echo esc_html($stone_w); ?></td></tr>
            <tr><td>Stone Color</td><td><?php echo esc_html($stone_c); ?></td></tr>
            <tr><td>Stone Clarity</td><td><?php echo esc_html($stone_cl); ?></td></tr>
            <tr><td>Certificate</td><td><?php echo esc_html($cert ?: 'None'); ?></td></tr>
        </table>
    </div>
    <div class="noah-payout">
        <h3 style="margin:0 0 6px;font-size:16px;">Payout Breakdown</h3>
        <div style="font-size:12px;color:#8b8b85;margin-bottom:14px;">Estimated amounts, subject to final inspection.</div>
        <div class="row"><span>Estimated Valuation</span><span><?php echo wp_kses_post(wc_price($valuation)); ?></span></div>
        <div class="row"><span>NOAH Commission</span><span>− <?php echo wp_kses_post(wc_price($commission)); ?></span></div>
        <div class="row"><span>Processing Fees</span><span>− <?php echo wp_kses_post(wc_price($fees)); ?></span></div>
        <div class="row total"><span>Estimated Payout</span><span class="amt"><?php echo wp_kses_post(wc_price($payout)); ?></span></div>
    </div>
    <div class="noah-timeline">
        <?php
        $labels = [
            'received'  => 'Item Received',
            'valuation' => 'Valuation',
            'approved'  => 'Approved',
            'payout'    => 'Payout Complete',
        ];
        $done_n = ($status === 'rejected') ? 1 : max(0, $idx);
        foreach ($flow as $i => $key): ?>
        <div class="noah-step <?php echo $i < $done_n || ($status === 'rejected' && $i === 0) ? 'done' : ''; ?>">
            <span class="noah-dot"><?php echo $i < $done_n ? '✓' : esc_html($i + 1); ?></span>
            <div class="noah-step-label"><?php echo esc_html($labels[$key]); ?></div>
        </div>
        <?php endforeach; ?>
    </div>
    <?php
    if ($status === 'rejected'): ?>
    <div class="noah-empty" style="padding:20px;">
        <p><strong>Update:</strong> This item was not approved during review. Contact NOAH support for details.</p>
    </div>
    <?php endif;
}

/* ============================================================
   9. SHORTCODE
   ============================================================ */
add_shortcode('noah_hub_dashboard', function ($atts) {
    if (!is_user_logged_in()) {
        return '<p>' . esc_html__('Please log in to view your NOAH dashboard.', 'noah') . '</p>';
    }
    $atts = shortcode_atts(['tab' => 'dashboard'], $atts);
    ob_start();
    switch ($atts['tab']) {
        case 'selling': noah_render_selling_requests(); break;
        case 'notifications': noah_render_notifications(); break;
        case 'returns': noah_render_returns(); break;
        default: noah_render_dashboard();
    }
    return ob_get_clean();
});
<?php
/*
Plugin Name: NOAH Sell With NOAH - Complete Workflow
Description: Complete consignment workflow with notifications, seller dashboard, and payout management
Version: 2.2
Author: NOAH Dev Team
*/

/* ==========================================
   1. PERMANENT SAFETY NET
   ========================================== */
add_filter('pre_option_woocommerce_hide_out_of_stock_items', function () {
    return 'no';
});

/* ==========================================
   2. CPT: noah_sell_lead & noah_consignment
   ========================================== */
add_action('init', function () {
    register_post_type('noah_sell_lead', array(
        'label' => 'Sales Requests',
        'labels' => array(
            'name' => 'Sales Requests',
            'singular_name' => 'Sales Request',
            'add_new' => 'New Request',
            'add_new_item' => 'Add New Sales Request',
            'edit_item' => 'Edit Request',
            'view_item' => 'View Request',
        ),
        'public' => false,
        'show_ui' => true,
        'show_in_menu' => true,
        'menu_icon' => 'dashicons-cart',
        'supports' => array('title'),
        'capability_type' => 'post',
        'map_meta_cap' => true,
    ));

    register_post_type('noah_consignment', array(
        'label' => 'Consignments',
        'labels' => array(
            'name' => 'Consignments',
            'singular_name' => 'Consignment',
        ),
        'public' => false,
        'show_ui' => true,
        'show_in_menu' => true,
        'menu_icon' => 'dashicons-airplane',
        'supports' => array('title'),
        'capability_type' => 'post',
        'map_meta_cap' => true,
    ));
});

/* ==========================================
   3. ADD "SELL WITH NOAH" BUTTON TO PRODUCTS
   ========================================== */

// Add to shop/archive pages (product cards)
add_action('woocommerce_after_shop_loop_item', 'noah_add_sell_button_to_product_cards', 15);
function noah_add_sell_button_to_product_cards() {
    global $product;
    echo '<a href="/sell-with-noah" class="button noah-sell-button" style="margin-top: 10px; background: #1e3a5f; color: #fff; padding: 8px 16px; border-radius: 4px; text-decoration: none; display: inline-block; font-size: 13px;">';
    echo '💰 Sell Yours';
    echo '</a>';
}

// Add to single product page
add_action('woocommerce_single_product_summary', 'noah_add_sell_button_to_single_product', 35);
function noah_add_sell_button_to_single_product() {
    echo '<div class="noah-sell-cta" style="margin-top: 20px; padding: 20px; background: #f8f9fa; border-radius: 8px; border: 2px solid #C9A467;">';
    echo '<p style="margin: 0 0 10px; font-weight: 600; color: #1B2430;">💰 Have a similar item to sell?</p>';
    echo '<a href="/sell-with-noah" class="button" style="background: #C9A467; color: #fff; padding: 12px 24px; border-radius: 4px; text-decoration: none; display: inline-block; font-weight: 600;">Sell with NOAH</a>';
    echo '</div>';
}

/* ==========================================
   4. ADMIN META BOX — Complete detail view
   ========================================== */
add_action('add_meta_boxes', function () {
    add_meta_box('noah_lead_details', 'Request Details', function ($post) {
        $category   = get_post_meta($post->ID, '_noah_lead_category', true);
        $metal      = get_post_meta($post->ID, '_noah_lead_metal', true);
        $fineness   = get_post_meta($post->ID, '_noah_lead_fineness', true);
        $weight     = get_post_meta($post->ID, '_noah_lead_weight', true);
        $condition  = get_post_meta($post->ID, '_noah_lead_condition', true);
        $brand      = get_post_meta($post->ID, '_noah_lead_brand', true);
        $desc       = get_post_meta($post->ID, '_noah_lead_description', true);
        $name       = get_post_meta($post->ID, '_noah_lead_name', true);
        $email      = get_post_meta($post->ID, '_noah_lead_email', true);
        $phone      = get_post_meta($post->ID, '_noah_lead_phone', true);
        $country    = get_post_meta($post->ID, '_noah_lead_country', true);
        $city       = get_post_meta($post->ID, '_noah_lead_city', true);
        $address    = get_post_meta($post->ID, '_noah_lead_address', true);
        $contact_pref = get_post_meta($post->ID, '_noah_lead_contact_pref', true);
        $message    = get_post_meta($post->ID, '_noah_lead_message', true);
        $status     = get_post_meta($post->ID, '_noah_lead_status', true) ?: 'new';
        $images     = get_post_meta($post->ID, '_noah_lead_images', true);
        $documents  = get_post_meta($post->ID, '_noah_lead_documents', true);
        $converted_item = get_post_meta($post->ID, '_noah_lead_converted_item_id', true);

        wp_nonce_field('noah_lead_save', 'noah_lead_nonce');
        ?>
        <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 20px;">
            <div>
                <h4>Product Information</h4>
                <p><strong>Category:</strong> <?php echo esc_html($category); ?></p>
                <p><strong>Metal:</strong> <?php echo esc_html($metal); ?></p>
                <p><strong>Fineness:</strong> <?php echo esc_html($fineness); ?></p>
                <p><strong>Weight:</strong> <?php echo esc_html($weight); ?> g</p>
                <p><strong>Condition:</strong> <?php echo esc_html($condition); ?></p>
                <p><strong>Brand/Manufacturer:</strong> <?php echo esc_html($brand ?: '—'); ?></p>
                <p><strong>Description:</strong><br><?php echo nl2br(esc_html($desc)); ?></p>
            </div>
            <div>
                <h4>Contact Information</h4>
                <p><strong>Name:</strong> <?php echo esc_html($name); ?></p>
                <p><strong>Email:</strong> <a href="mailto:<?php echo esc_attr($email); ?>"><?php echo esc_html($email); ?></a></p>
                <p><strong>Phone:</strong> <?php echo esc_html($phone); ?></p>
                <p><strong>Address:</strong> <?php echo esc_html($address); ?>, <?php echo esc_html($city); ?>, <?php echo esc_html($country); ?></p>
                <p><strong>Preferred Contact:</strong> <?php echo esc_html($contact_pref); ?></p>
                <?php if ($message) : ?>
                    <p><strong>Message:</strong><br><?php echo nl2br(esc_html($message)); ?></p>
                <?php endif; ?>
            </div>
        </div>

        <?php if (!empty($images) && is_array($images)) : ?>
            <h4>Product Photos</h4>
            <div style="display:flex;gap:10px;flex-wrap:wrap; margin: 15px 0;">
                <?php foreach ($images as $img_id) :
                    $url = wp_get_attachment_image_url($img_id, 'medium');
                    if ($url) : ?>
                        <a href="<?php echo esc_url(wp_get_attachment_url($img_id)); ?>" target="_blank">
                            <img src="<?php echo esc_url($url); ?>" style="width:150px;height:150px;object-fit:cover;border-radius:4px;border:1px solid #ddd;">
                        </a>
                    <?php endif;
                endforeach; ?>
            </div>
        <?php endif; ?>

        <?php if (!empty($documents) && is_array($documents)) : ?>
            <h4>Documents & Certificates</h4>
            <ul>
                <?php foreach ($documents as $doc_id) :
                    $url = wp_get_attachment_url($doc_id);
                    if ($url) : ?>
                        <li><a href="<?php echo esc_url($url); ?>" target="_blank"><?php echo esc_html(basename($url)); ?></a></li>
                    <?php endif;
                endforeach; ?>
            </ul>
        <?php endif; ?>

        <hr style="margin: 30px 0;">
        
        <p>
            <label><strong>Request Status:</strong><br>
                <select name="noah_lead_status" style="width: 100%; padding: 8px;">
                    <option value="new" <?php selected($status, 'new'); ?>> New</option>
                    <option value="contacted" <?php selected($status, 'contacted'); ?>>📞 Contacted</option>
                    <option value="evaluation" <?php selected($status, 'evaluation'); ?>> Under Review</option>
                    <option value="agreement" <?php selected($status, 'agreement'); ?>>📋 Agreement Reached</option>
                    <option value="received" <?php selected($status, 'received'); ?>>📦 Arrived at NOAH</option>
                    <option value="published" <?php selected($status, 'published'); ?>>🌐 Published</option>
                    <option value="sold" <?php selected($status, 'sold'); ?>>✅ Sold</option>
                    <option value="picked_up" <?php selected($status, 'picked_up'); ?>>🎁 Picked Up</option>
                    <option value="closed" <?php selected($status, 'closed'); ?>>✔️ Completed</option>
                </select>
            </label>
        </p>

        <?php if ($converted_item) : ?>
            <div style="background: #e7f5ee; border: 1px solid #00a32a; border-radius: 4px; padding: 15px; margin-top: 20px;">
                <p style="margin: 0; color: #00a32a;">
                    <strong>✅ Already added to inventory:</strong><br>
                    <a href="<?php echo esc_url(get_edit_post_link($converted_item)); ?>">Product #<?php echo esc_html($converted_item); ?> View</a>
                </p>
            </div>
        <?php else : ?>
            <div style="background: #fff8e1; border: 1px solid #dba617; border-radius: 4px; padding: 15px; margin-top: 20px;">
                <p><strong> When the product physically arrives at NOAH:</strong></p>
                <a href="<?php echo esc_url(wp_nonce_url(admin_url('admin-post.php?action=noah_convert_lead&lead_id=' . $post->ID), 'noah_convert_lead_' . $post->ID)); ?>" class="button button-primary button-hero">
                    Add to Inventory & Create Consignment
                </a>
                <p style="font-size:12px;color:#666; margin-top: 10px;">
                    Creates a NOAH Inventory Item, automatically links it to the customer account (via email match) and makes it visible in "My Sales".
                </p>
            </div>
        <?php endif; ?>
        <?php
    }, 'noah_sell_lead', 'normal', 'high');
});

add_action('save_post_noah_sell_lead', function ($post_id) {
    if (!isset($_POST['noah_lead_nonce']) || !wp_verify_nonce($_POST['noah_lead_nonce'], 'noah_lead_save')) {
        return;
    }
    if (isset($_POST['noah_lead_status'])) {
        $old_status = get_post_meta($post_id, '_noah_lead_status', true);
        $new_status = sanitize_text_field($_POST['noah_lead_status']);
        update_post_meta($post_id, '_noah_lead_status', $new_status);
        
        if ($old_status !== $new_status) {
            noah_send_lead_status_notification($post_id, $new_status);
        }
    }
});

/* ==========================================
   5. NOTIFICATION FUNCTIONS - FIXED
   ========================================== */
function noah_send_lead_status_notification($lead_id, $new_status) {
    $email = get_post_meta($lead_id, '_noah_lead_email', true);
    $name = get_post_meta($lead_id, '_noah_lead_name', true);
    $category = get_post_meta($lead_id, '_noah_lead_category', true);
    
    $status_messages = array(
        'new' => 'Your sales request has been successfully submitted',
        'contacted' => 'NOAH has received your request and will contact you',
        'evaluation' => 'Your item is being evaluated by NOAH',
        'agreement' => 'Agreement reached - Your item is being prepared',
        'received' => 'Your item has arrived at NOAH',
        'published' => 'Your item has been published',
        'sold' => 'Your item has been sold!',
        'picked_up' => 'Your item has been picked up',
        'closed' => 'Payment has been processed',
        'completed' => 'Your transaction has been completed'
    );
    
    $subject = 'NOAH Edelmetalle - Update on Your Sales Request';
    $message = "Dear {$name},\n\n";
    $message .= "We would like to inform you about the current status of your sales request:\n\n";
    $message .= "Product: {$category}\n";
    $message .= "Status: " . ($status_messages[$new_status] ?? 'In Progress') . "\n\n";
    $message .= "You can check the status at any time in your account under \"My Sales\".\n\n";
    $message .= "Best regards,\nYour NOAH Team";
    
    $headers = array('Content-Type: text/plain; charset=UTF-8');
    
    // Log the email attempt
    error_log("NOAH: Sending status update to {$email} for lead {$lead_id}");
    
    $sent = wp_mail($email, $subject, $message, $headers);
    
    if (!$sent) {
        error_log("NOAH: Failed to send email to {$email}");
    }
}

function noah_send_admin_notification($lead_id, $user_name, $category) {
    $admin_email = get_option('admin_email');
    $subject = '🆕 New Sales Request from ' . $user_name;
    $message = "A new sales request has been received:\n\n";
    $message .= "Name: {$user_name}\n";
    $message .= "Category: {$category}\n";
    $message .= "Lead ID: {$lead_id}\n";
    $message .= "Link to process: " . admin_url('post.php?post=' . $lead_id . '&action=edit') . "\n\n";
    $message .= "Submitted at: " . current_time('F j, Y g:i a');
    
    $headers = array('Content-Type: text/plain; charset=UTF-8');
    
    // Log the email attempt
    error_log("NOAH: Sending admin notification to {$admin_email} for lead {$lead_id}");
    
    $sent = wp_mail($admin_email, $subject, $message, $headers);
    
    if (!$sent) {
        error_log("NOAH: Failed to send admin notification to {$admin_email}");
    }
}

/* ==========================================
   TEST EMAIL FUNCTION (for debugging)
   ========================================== */
function noah_test_email_notifications() {
    $admin_email = get_option('admin_email');
    $test_subject = 'NOAH Email Test';
    $test_message = 'If you receive this, email notifications are working!';
    
    $sent = wp_mail($admin_email, $test_subject, $test_message);
    
    if ($sent) {
        echo "✓ Test email sent successfully to {$admin_email}";
    } else {
        echo "✗ Failed to send test email. Check your server configuration.";
    }
}
// Run test: noah_test_email_notifications();

/* ==========================================
   6. CONVERT LEAD → Consignment Item
   ========================================== */
add_action('admin_post_noah_convert_lead', function () {
    $lead_id = intval($_GET['lead_id'] ?? 0);
    if (!$lead_id || !current_user_can('manage_woocommerce') || !wp_verify_nonce($_GET['_wpnonce'] ?? '', 'noah_convert_lead_' . $lead_id)) {
        wp_die('Not allowed.');
    }
    if (get_post_meta($lead_id, '_noah_lead_converted_item_id', true)) {
        wp_redirect(get_edit_post_link($lead_id, 'raw'));
        exit;
    }

    $email   = get_post_meta($lead_id, '_noah_lead_email', true);
    $name    = get_post_meta($lead_id, '_noah_lead_name', true);
    $category = get_post_meta($lead_id, '_noah_lead_category', true);
    $metal   = get_post_meta($lead_id, '_noah_lead_metal', true);
    $weight  = get_post_meta($lead_id, '_noah_lead_weight', true);
    $images  = get_post_meta($lead_id, '_noah_lead_images', true);

    $user = $email ? get_user_by('email', $email) : false;

    $title = trim($category . ' ' . $metal . ($weight ? ' (' . $weight . 'g)' : ''));
    $item_id = wp_insert_post(array(
        'post_type'   => 'noah_consignment',
        'post_title'  => $title ?: $name,
        'post_status' => 'publish',
    ));

    update_post_meta($item_id, '_noah_ownership', 'consignment');
    update_post_meta($item_id, '_noah_owner_name', $name);
    update_post_meta($item_id, '_noah_owner_email', $email);
    if ($user) {
        update_post_meta($item_id, '_noah_owner_user_id', $user->ID);
    }
    update_post_meta($item_id, '_noah_date_received', current_time('Y-m-d'));
    update_post_meta($item_id, '_noah_lead_id', $lead_id);
    update_post_meta($item_id, '_noah_consignment_status', 'received');
    update_post_meta($item_id, '_noah_payout_status', 'pending');

    if (!empty($images) && is_array($images)) {
        set_post_thumbnail($item_id, $images[0]);
    }

    update_post_meta($lead_id, '_noah_lead_converted_item_id', $item_id);
    update_post_meta($lead_id, '_noah_lead_status', 'received');

    noah_send_lead_status_notification($lead_id, 'received');

    wp_redirect(get_edit_post_link($item_id, 'raw'));
    exit;
});

/* ==========================================
   7. [noah_sell_request_form] — 4-step wizard
   ========================================== */
add_shortcode('noah_sell_request_form', function ($atts) {
    ob_start();
    ?>
    <div class="noah-wizard-container">
        <div class="noah-wizard-header">
            <div class="noah-wizard-breadcrumb">Home / SELL NOW</div>
            <h1 class="noah-wizard-h1">Turn Your Precious Items Into Cash</h1>
            <p class="noah-wizard-sub">Tell us about your item. Our specialists will review the details and contact you with the next steps.</p>
        </div>

        <div class="noah-wizard-progress" id="noah-wizard-progress">
            <div class="noah-step-dot" data-step="1">
                <span class="noah-step-circle">1</span>
                <span class="noah-step-label">Item Details</span>
            </div>
            <div class="noah-step-bar" data-bar="1"></div>
            <div class="noah-step-dot" data-step="2">
                <span class="noah-step-circle">2</span>
                <span class="noah-step-label">Upload Photos</span>
            </div>
            <div class="noah-step-bar" data-bar="2"></div>
            <div class="noah-step-dot" data-step="3">
                <span class="noah-step-circle">3</span>
                <span class="noah-step-label">Contact Info</span>
            </div>
            <div class="noah-step-bar" data-bar="3"></div>
            <div class="noah-step-dot" data-step="4">
                <span class="noah-step-circle">4</span>
                <span class="noah-step-label">Review & Submit</span>
            </div>
        </div>

        <form id="noah-sell-wizard-form" enctype="multipart/form-data" novalidate>
            <!-- STEP 1: Item Details -->
            <div class="noah-wizard-panel" data-panel="1">
                <h3>Item Details</h3>
                <p class="noah-wizard-sub">Please provide detailed information about your item</p>
                
                <div class="noah-grid-2">
                    <label>Item Type <span style="color: #b3392c;">*</span>
                        <select name="item_category" data-required="1">
                            <option value="">Please select</option>
                            <option value="Jewelry">Jewelry</option>
                            <option value="Coins">Coins</option>
                            <option value="Bars">Bars</option>
                            <option value="Diamonds/Gemstones">Diamonds / Gemstones</option>
                            <option value="Other">Other</option>
                        </select>
                    </label>
                    <label>Metal Type
                        <select name="metal_type">
                            <option value="">Please select</option>
                            <option value="Gold">Gold</option>
                            <option value="Silver">Silver</option>
                            <option value="Platinum">Platinum</option>
                            <option value="Palladium">Palladium</option>
                            <option value="N/A">N/A</option>
                        </select>
                    </label>
                </div>
                
                <div class="noah-grid-2">
                    <label>Fineness / Purity
                        <select name="fineness">
                            <option value="">Please select</option>
                            <option value="999.9">999.9</option>
                            <option value="999">999</option>
                            <option value="958">958</option>
                            <option value="925">925 (Sterling)</option>
                            <option value="916">916</option>
                            <option value="900">900</option>
                            <option value="750">750 (18K)</option>
                            <option value="585">585 (14K)</option>
                            <option value="375">375 (9K)</option>
                            <option value="Unknown">Unknown</option>
                        </select>
                    </label>
                    <label>Weight (g)
                        <input type="number" step="0.01" name="weight" placeholder="4.50">
                    </label>
                </div>
                
                <div class="noah-grid-2">
                    <label>Condition
                        <select name="condition">
                            <option value="Like New">Like New — No visible signs of wear</option>
                            <option value="Very Good">Very Good — Minimal signs of wear</option>
                            <option value="Good">Good — Visible, normal signs of wear</option>
                            <option value="Fair">Fair — Clear signs of wear</option>
                        </select>
                    </label>
                    <label>Brand / Manufacturer (optional)
                        <input type="text" name="brand" placeholder="e.g. Chopard, Rolex">
                    </label>
                </div>
                
                <label>Item Description
                    <textarea name="description" rows="4" placeholder="Vintage 18K yellow gold ring with engraved floral motif..."></textarea>
                </label>
                
                <p class="noah-wizard-hint">Providing accurate information helps us evaluate your item more efficiently.</p>
                <p class="noah-wizard-error" data-error-for="1" style="display:none;color:#b3392c;font-size:13px;"></p>
                
                <div class="noah-wizard-actions">
                    <button type="button" class="noah-btn-outline" data-cancel>Cancel</button>
                    <button type="button" class="noah-btn-gold" data-next="2">Continue</button>
                </div>
            </div>

            <!-- STEP 2: Upload Photos -->
            <div class="noah-wizard-panel" data-panel="2" style="display:none;">
                <h3>Show Us Your Item</h3>
                <p class="noah-wizard-sub">Upload clear photos and any documents that can help our specialists evaluate your item.</p>

                <label class="noah-dropzone">
                    <strong>Add clear photos of the front, back, side, details, and any visible markings.</strong>
                    <span>Drop files here or browse from your device</span>
                    <input type="file" name="noah_photos_native" multiple accept="image/*" class="noah-file-input" data-target="photos">
                </label>
                <div class="noah-file-chips" id="noah-photo-chips"></div>

                <label class="noah-wizard-hint" style="display:block;margin-top:20px;">Upload certificates, invoices, appraisals, or proof of authenticity if available.</label>
                <label class="noah-dropzone">
                    <span>Drop files here or browse from your device</span>
                    <input type="file" name="noah_documents_native" multiple class="noah-file-input" data-target="documents">
                </label>
                <div class="noah-file-chips" id="noah-document-chips"></div>

                <div class="noah-wizard-actions">
                    <button type="button" class="noah-btn-outline" data-prev="1">Back</button>
                    <button type="button" class="noah-btn-gold" data-next="3">Continue</button>
                </div>
            </div>

            <!-- STEP 3: Contact Info -->
            <div class="noah-wizard-panel" data-panel="3" style="display:none;">
                <h3>Contact Information</h3>
                <p class="noah-wizard-sub">How can we reach you?</p>
                
                <div class="noah-grid-2">
                    <label>Full Name <span style="color: #b3392c;">*</span>
                        <input type="text" name="name" data-required="1" placeholder="Full Name">
                    </label>
                    <label>Email Address <span style="color: #b3392c;">*</span>
                        <input type="email" name="email" data-required="1" placeholder="name@example.com">
                    </label>
                </div>
                
                <div class="noah-grid-2">
                    <label>Phone
                        <div style="display: flex; gap: 10px;">
                            <select name="phone_country" style="width: 80px;">
                                <option value="+43" selected>🇦🇹 Austria</option>
                                <option value="+32">🇧🇪 Belgium</option>
                                <option value="+359">🇧🇬 Bulgaria</option>
                                <option value="+385">🇭🇷 Croatia</option>
                                <option value="+357">🇾 Cyprus</option>
                                <option value="+420">🇨🇿 Czech Republic</option>
                                <option value="+45">🇩🇰 Denmark</option>
                                <option value="+372">🇪 Estonia</option>
                                <option value="+358">🇫🇮 Finland</option>
                                <option value="+33">🇫🇷 France</option>
                                <option value="+49">🇩🇪 Germany</option>
                                <option value="+30">🇬🇷 Greece</option>
                                <option value="+36">🇭🇺 Hungary</option>
                                <option value="+353">🇪 Ireland</option>
                                <option value="+39">🇮🇹 Italy</option>
                                <option value="+371">🇱🇻 Latvia</option>
                                <option value="+370">🇹 Lithuania</option>
                                <option value="+352">🇺 Luxembourg</option>
                                <option value="+356">🇲🇹 Malta</option>
                                <option value="+31">🇳🇱 Netherlands</option>
                                <option value="+48">🇵🇱 Poland</option>
                                <option value="+351">🇵🇹 Portugal</option>
                                <option value="+40">🇷🇴 Romania</option>
                                <option value="+421">🇸🇰 Slovakia</option>
                                <option value="+386">🇸 Slovenia</option>
                                <option value="+34">🇪🇸 Spain</option>
                                <option value="+46">🇪 Sweden</option>
                                <option value="+41">🇨🇭 Switzerland</option>
                                <option value="+44">🇬🇧 United Kingdom</option>
                                <option value="+1">🇺🇸 United States</option>
                                <option value="+1">🇨🇦 Canada</option>
                            </select>
                            <input type="tel" name="phone" placeholder="660 123 4567" style="flex: 1;">
                        </div>
                    </label>
                    <label>Country
                        <input type="text" name="country" placeholder="Austria">
                    </label>
                </div>
                
                <div class="noah-grid-2">
                    <label>City
                        <input type="text" name="city" placeholder="Vienna">
                    </label>
                    <label>Address
                        <input type="text" name="address" placeholder="Graben 14, 1010 Wien">
                    </label>
                </div>
                
                <label>Preferred Contact Method <span style="color: #b3392c;">*</span>
                    <span style="display:flex;gap:20px;margin-top:6px;">
                        <label style="display:flex;align-items:center;gap:6px;font-weight:normal;cursor:pointer;">
                            <input type="radio" name="contact_pref" value="Email" checked> Email
                        </label>
                        <label style="display:flex;align-items:center;gap:6px;font-weight:normal;cursor:pointer;">
                            <input type="radio" name="contact_pref" value="Phone"> Phone
                        </label>
                    </span>
                </label>
                
                <label>Additional Message
                    <textarea name="message" rows="3" placeholder="Anything else you would like our team to know?"></textarea>
                </label>
                
                <p class="noah-wizard-error" data-error-for="3" style="display:none;color:#b3392c;font-size:13px;"></p>
                
                <div class="noah-wizard-actions">
                    <button type="button" class="noah-btn-outline" data-prev="2">Back</button>
                    <button type="button" class="noah-btn-gold" data-next="4">Continue</button>
                </div>
            </div>

            <!-- STEP 4: Review & Submit -->
            <div class="noah-wizard-panel" data-panel="4" style="display:none;">
                <h3>Review & Submit</h3>
                <p class="noah-wizard-sub">Please review your information before submitting</p>
                
                <div class="noah-review-card">
                    <div class="noah-review-card-head">
                        <strong>Item Details</strong> 
                        <a href="#" data-edit="1">Edit</a>
                    </div>
                    <div class="noah-review-grid" id="noah-review-item"></div>
                </div>
                
                <div class="noah-review-card">
                    <div class="noah-review-card-head">
                        <strong>Photos & Documents</strong> 
                        <a href="#" data-edit="2">Edit</a>
                    </div>
                    <div class="noah-review-grid" id="noah-review-photos"></div>
                </div>
                
                <div class="noah-review-card">
                    <div class="noah-review-card-head">
                        <strong>Contact Info</strong> 
                        <a href="#" data-edit="3">Edit</a>
                    </div>
                    <div class="noah-review-grid" id="noah-review-contact"></div>
                </div>
                
                <div class="noah-terms-check" style="margin: 20px 0; padding: 15px; background: #f8f9fa; border-radius: 4px;">
                    <label style="display: flex; align-items: flex-start; gap: 10px; cursor: pointer;">
                        <input type="checkbox" id="noah-terms-agree" style="margin-top: 3px;">
                        <span style="font-size: 13px; color: #666;">
                            I agree to NOAH's evaluation terms and authorize NOAH to examine my item(s). I understand that NOAH will contact me within 2 business days.
                        </span>
                    </label>
                </div>
                
                <div class="noah-wizard-actions">
                    <button type="button" class="noah-btn-outline" data-prev="3">Back</button>
                    <button type="button" id="noah-wizard-submit-btn" class="noah-btn-gold">Submit for Evaluation</button>
                </div>
            </div>
        </form>
        
        <div id="noah-wizard-msg"></div>
    </div>

    <style>
        .noah-wizard-container { 
            max-width: 900px; 
            margin: 0 auto; 
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Oxygen, Ubuntu, Cantarell, sans-serif;
            padding: 40px 20px;
        }
        .noah-wizard-header { text-align: center; margin-bottom: 40px; }
        .noah-wizard-breadcrumb { font-size: 13px; color: #8A8578; margin-bottom: 8px; text-transform: uppercase; letter-spacing: 0.5px; }
        .noah-wizard-h1 { 
            font-family: 'Playfair Display', Georgia, serif; 
            font-size: 36px; 
            color: #1B2430; 
            margin: 0 0 12px; 
            font-weight: 600;
        }
        .noah-wizard-sub { color: #6B6558; margin-bottom: 30px; font-size: 16px; }
        
        .noah-wizard-progress { 
            display: flex; 
            align-items: center; 
            justify-content: center;
            margin-bottom: 50px; 
            padding: 20px;
            background: #fafafa;
            border-radius: 8px;
        }
        .noah-step-dot { 
            display: flex; 
            flex-direction: column; 
            align-items: center; 
            gap: 8px; 
            flex: 0 0 auto;
            z-index: 2;
        }
        .noah-step-circle { 
            width: 42px; 
            height: 42px; 
            border-radius: 50%; 
            display: flex; 
            align-items: center; 
            justify-content: center; 
            border: 2px solid #D8CFBC; 
            color: #8A8578; 
            font-weight: 600; 
            background: #fff;
            transition: all 0.3s ease;
        }
        .noah-step-label { 
            font-size: 12px; 
            color: #8A8578; 
            white-space: nowrap;
            font-weight: 500;
        }
        .noah-step-bar { 
            flex: 1 1 auto; 
            height: 2px; 
            background: #D8CFBC; 
            margin: 0 8px;
            max-width: 120px;
            transition: all 0.3s ease;
        }
        .noah-step-dot.is-current .noah-step-circle { 
            background: #C9A467; 
            border-color: #C9A467; 
            color: #fff;
            transform: scale(1.1);
        }
        .noah-step-dot.is-current .noah-step-label { 
            color: #1B2430; 
            font-weight: 600; 
        }
        .noah-step-dot.is-complete .noah-step-circle { 
            background: #C9A467; 
            border-color: #C9A467; 
            color: #fff;
        }
        .noah-step-dot.is-complete .noah-step-circle::after { 
            content: "✓"; 
            font-size: 18px;
        }
        .noah-step-dot.is-complete .noah-step-circle { 
            font-size: 0; 
        }
        .noah-step-bar.is-complete { 
            background: #C9A467; 
        }

        .noah-wizard-panel h3 {
            font-family: 'Playfair Display', Georgia, serif;
            font-size: 24px;
            color: #1B2430;
            margin: 0 0 10px;
        }
        
        .noah-wizard-panel label { 
            display: block; 
            font-size: 13px; 
            color: #3C3A34; 
            font-weight: 600; 
            margin-bottom: 20px; 
        }
        .noah-wizard-panel input[type="text"], 
        .noah-wizard-panel input[type="email"], 
        .noah-wizard-panel input[type="tel"], 
        .noah-wizard-panel input[type="number"], 
        .noah-wizard-panel select, 
        .noah-wizard-panel textarea {
            display: block; 
            width: 100%; 
            padding: 14px 16px; 
            border: 1.5px solid #D8CFBC; 
            border-radius: 6px; 
            font-weight: normal; 
            margin-top: 8px; 
            font-size: 15px; 
            box-sizing: border-box;
            transition: border-color 0.3s ease;
        }
        .noah-wizard-panel input:focus,
        .noah-wizard-panel select:focus,
        .noah-wizard-panel textarea:focus {
            outline: none;
            border-color: #C9A467;
        }
        .noah-grid-2 { 
            display: grid; 
            grid-template-columns: 1fr 1fr; 
            gap: 24px; 
            margin-bottom: 20px;
        }
        .noah-wizard-hint { 
            font-size: 13px; 
            color: #8A8578; 
            margin: 15px 0 25px;
            font-style: italic;
        }
        .noah-wizard-actions { 
            display: flex; 
            justify-content: flex-end; 
            gap: 16px; 
            margin-top: 30px;
            padding-top: 30px;
            border-top: 1px solid #eee;
        }
        .noah-btn-gold { 
            background: #C9A467; 
            color: #fff; 
            border: none; 
            padding: 14px 32px; 
            border-radius: 6px; 
            font-weight: 600; 
            cursor: pointer;
            font-size: 15px;
            transition: all 0.3s ease;
            box-shadow: 0 2px 8px rgba(201, 164, 103, 0.3);
        }
        .noah-btn-gold:hover {
            background: #b89456;
            transform: translateY(-1px);
            box-shadow: 0 4px 12px rgba(201, 164, 103, 0.4);
        }
        .noah-btn-outline { 
            background: transparent; 
            color: #1B2430; 
            border: 1.5px solid #D8CFBC; 
            padding: 14px 32px; 
            border-radius: 6px; 
            font-weight: 600; 
            cursor: pointer;
            font-size: 15px;
            transition: all 0.3s ease;
        }
        .noah-btn-outline:hover {
            background: #f5f5f5;
            border-color: #C9A467;
        }

        .noah-dropzone { 
            display: flex; 
            flex-direction: column; 
            align-items: center; 
            text-align: center; 
            gap: 10px; 
            border: 2.5px dashed #D8CFBC; 
            border-radius: 10px; 
            padding: 40px 30px; 
            cursor: pointer; 
            font-weight: normal;
            transition: all 0.3s ease;
            background: #fafafa;
        }
        .noah-dropzone:hover {
            border-color: #C9A467;
            background: #fff8f0;
        }
        .noah-dropzone strong {
            color: #1B2430;
            font-size: 15px;
        }
        .noah-dropzone span { 
            font-size: 14px; 
            color: #8A8578; 
        }
        .noah-file-input { display: none; }
        .noah-file-chips { 
            display: flex; 
            gap: 12px; 
            flex-wrap: wrap; 
            margin-top: 20px; 
        }
        .noah-file-chip { 
            background: #F2E9DC; 
            border: 1px solid #D8CFBC; 
            border-radius: 6px; 
            padding: 10px 16px; 
            font-size: 13px; 
            display: flex; 
            align-items: center; 
            gap: 10px;
            animation: slideIn 0.3s ease;
        }
        @keyframes slideIn {
            from { opacity: 0; transform: translateY(-10px); }
            to { opacity: 1; transform: translateY(0); }
        }
        .noah-file-chip a { 
            cursor: pointer; 
            color: #b3392c; 
            text-decoration: none; 
            font-weight: bold;
            font-size: 16px;
        }
        .noah-file-chip a:hover {
            color: #8b0000;
        }

        .noah-review-card { 
            border: 1.5px solid #EDE6D6; 
            border-radius: 8px; 
            padding: 24px; 
            margin-bottom: 20px;
            background: #fff;
        }
        .noah-review-card-head { 
            display: flex; 
            justify-content: space-between; 
            align-items: center;
            margin-bottom: 16px;
            padding-bottom: 12px;
            border-bottom: 1px solid #eee;
        }
        .noah-review-card-head strong {
            font-size: 16px;
            color: #1B2430;
        }
        .noah-review-card-head a { 
            color: #C9A467; 
            font-size: 13px;
            text-decoration: none;
            font-weight: 600;
        }
        .noah-review-card-head a:hover {
            text-decoration: underline;
        }
        .noah-review-grid { 
            display: grid; 
            grid-template-columns: 1fr 1fr; 
            gap: 14px; 
            font-size: 14px; 
            color: #3C3A34; 
        }
        .noah-review-grid div {
            padding: 8px 0;
        }
        .noah-review-grid div span { 
            display: block; 
            font-size: 12px; 
            color: #8A8578;
            margin-bottom: 4px;
        }
        
        @media (max-width: 768px) {
            .noah-grid-2, .noah-review-grid { grid-template-columns: 1fr; }
            .noah-wizard-h1 { font-size: 28px; }
            .noah-step-label { font-size: 11px; }
            .noah-step-circle { width: 36px; height: 36px; font-size: 14px; }
        }
    </style>

    <script>
    (function () {
        var currentStep = 1;
        var photoFiles = [];
        var docFiles = [];
        var form = document.getElementById('noah-sell-wizard-form');
        if (!form) { return; }

        function updateProgress() {
            document.querySelectorAll('.noah-step-dot').forEach(function (dot) {
                var s = parseInt(dot.dataset.step, 10);
                dot.classList.remove('is-current', 'is-complete');
                if (s < currentStep) { dot.classList.add('is-complete'); }
                else if (s === currentStep) { dot.classList.add('is-current'); }
            });
            document.querySelectorAll('.noah-step-bar').forEach(function (bar) {
                var b = parseInt(bar.dataset.bar, 10);
                bar.classList.toggle('is-complete', b < currentStep);
            });
        }

        function goToStep(n) {
            document.querySelectorAll('.noah-wizard-panel').forEach(function (panel) {
                panel.style.display = (parseInt(panel.dataset.panel, 10) === n) ? 'block' : 'none';
            });
            currentStep = n;
            updateProgress();
            if (n === 4) { buildReview(); }
            var formTop = form.offsetTop - 100;
            window.scrollTo({ top: formTop, behavior: 'smooth' });
        }

        form.querySelectorAll('[data-next]').forEach(function (btn) {
            btn.addEventListener('click', function () {
                var panel = btn.closest('.noah-wizard-panel');
                var panelNum = panel.dataset.panel;
                var errorBox = form.querySelector('.noah-wizard-error[data-error-for="' + panelNum + '"]');
                var required = panel.querySelectorAll('[data-required]');
                var hasError = false;
                
                for (var i = 0; i < required.length; i++) {
                    if (!required[i].value.trim()) {
                        hasError = true;
                        required[i].style.borderColor = '#b3392c';
                        if (errorBox) { 
                            errorBox.textContent = 'Please fill in all required fields.'; 
                            errorBox.style.display = 'block'; 
                        }
                    } else {
                        required[i].style.borderColor = '#D8CFBC';
                    }
                }
                
                if (hasError) {
                    required[0].focus();
                    return;
                }
                
                if (errorBox) { errorBox.style.display = 'none'; }
                goToStep(parseInt(btn.dataset.next, 10));
            });
        });
        
        form.querySelectorAll('[data-prev]').forEach(function (btn) {
            btn.addEventListener('click', function () { 
                goToStep(parseInt(btn.dataset.prev, 10)); 
            });
        });
        
        form.querySelectorAll('[data-edit]').forEach(function (link) {
            link.addEventListener('click', function (e) { 
                e.preventDefault(); 
                goToStep(parseInt(link.dataset.edit, 10)); 
            });
        });
        
        var cancelBtn = form.querySelector('[data-cancel]');
        if (cancelBtn) {
            cancelBtn.addEventListener('click', function () { 
                if (confirm('Do you really want to cancel?')) {
                    form.reset(); 
                    photoFiles = []; 
                    docFiles = []; 
                    renderChips();
                    goToStep(1);
                }
            });
        }

        function renderChips() {
            var pWrap = document.getElementById('noah-photo-chips');
            pWrap.innerHTML = '';
            photoFiles.forEach(function (f, idx) {
                var chip = document.createElement('div');
                chip.className = 'noah-file-chip';
                chip.innerHTML = '<span>📷 ' + f.name + '</span> <a data-remove="' + idx + '">✕</a>';
                pWrap.appendChild(chip);
            });
            pWrap.querySelectorAll('[data-remove]').forEach(function (x) {
                x.addEventListener('click', function () { 
                    photoFiles.splice(parseInt(x.dataset.remove, 10), 1); 
                    renderChips(); 
                });
            });
            
            var dWrap = document.getElementById('noah-document-chips');
            dWrap.innerHTML = '';
            docFiles.forEach(function (f, idx) {
                var chip = document.createElement('div');
                chip.className = 'noah-file-chip';
                chip.innerHTML = '<span>📄 ' + f.name + '</span> <a data-removedoc="' + idx + '">✕</a>';
                dWrap.appendChild(chip);
            });
            dWrap.querySelectorAll('[data-removedoc]').forEach(function (x) {
                x.addEventListener('click', function () { 
                    docFiles.splice(parseInt(x.dataset.removedoc, 10), 1); 
                    renderChips(); 
                });
            });
        }

        form.querySelectorAll('.noah-file-input').forEach(function (input) {
            input.addEventListener('change', function () {
                var list = input.dataset.target === 'photos' ? photoFiles : docFiles;
                Array.prototype.forEach.call(input.files, function (f) { 
                    if (f.size > 10 * 1024 * 1024) {
                        alert('File ' + f.name + ' is too large. Maximum size: 10MB');
                        return;
                    }
                    list.push(f); 
                });
                renderChips();
                input.value = '';
            });
        });

        function val(name) {
            var el = form.querySelector('[name="' + name + '"]:checked, [name="' + name + '"]');
            return el ? el.value : '';
        }

        function buildReview() {
            document.getElementById('noah-review-item').innerHTML =
                '<div><span>Item Type</span>' + (val('item_category') || '—') + '</div>' +
                '<div><span>Metal Type</span>' + (val('metal_type') || '—') + '</div>' +
                '<div><span>Fineness</span>' + (val('fineness') || '—') + '</div>' +
                '<div><span>Weight</span>' + (val('weight') || '—') + ' g</div>' +
                '<div><span>Condition</span>' + (val('condition') || '—') + '</div>' +
                '<div><span>Brand</span>' + (val('brand') || '—') + '</div>' +
                '<div style="grid-column:1/3;"><span>Description</span>' + (val('description') || '—') + '</div>';
                
            document.getElementById('noah-review-photos').innerHTML =
                '<div><span>Photos</span>' + photoFiles.length + ' files uploaded' + (photoFiles.length > 0 ? ' ✓' : '') + '</div>' +
                '<div><span>Documents</span>' + docFiles.length + ' files uploaded' + (docFiles.length > 0 ? ' ✓' : '') + '</div>';
                
            document.getElementById('noah-review-contact').innerHTML =
                '<div><span>Name</span>' + (val('name') || '—') + '</div>' +
                '<div><span>Email</span>' + (val('email') || '—') + '</div>' +
                '<div><span>Phone</span>' + (val('phone_country') || '+43') + ' ' + (val('phone') || '—') + '</div>' +
                '<div><span>Country</span>' + (val('country') || '—') + '</div>' +
                '<div><span>City</span>' + (val('city') || '—') + '</div>' +
                '<div><span>Address</span>' + (val('address') || '—') + '</div>' +
                '<div><span>Preferred Contact</span>' + (val('contact_pref') || 'Email') + '</div>';
        }

        var submitBtn = document.getElementById('noah-wizard-submit-btn');
        submitBtn.addEventListener('click', function () {
            var termsCheckbox = document.getElementById('noah-terms-agree');
            if (!termsCheckbox.checked) {
                alert('Please agree to the evaluation terms.');
                termsCheckbox.focus();
                return;
            }
            
            if (!val('name') || !val('email')) {
                goToStep(3);
                return;
            }
            
            submitBtn.disabled = true;
            submitBtn.innerHTML = '<span style="display:inline-block; animation: spin 1s linear infinite;">⟳</span> Sending...';

            var data = new FormData(form);
            photoFiles.forEach(function (f) { data.append('photos[]', f); });
            docFiles.forEach(function (f) { data.append('documents[]', f); });
            data.append('action', 'noah_submit_sell_lead');
            data.append('nonce', '<?php echo esc_js(wp_create_nonce('noah_sell_lead_action')); ?>');

            fetch('<?php echo esc_url(admin_url('admin-ajax.php')); ?>', { 
                method: 'POST', 
                body: data, 
                credentials: 'same-origin' 
            })
            .then(function (r) { return r.json(); })
            .then(function (res) {
                var msg = document.getElementById('noah-wizard-msg');
                if (res.success) {
                    form.style.display = 'none';
                    document.getElementById('noah-wizard-progress').style.display = 'none';
                    document.querySelector('.noah-wizard-header').innerHTML = '<h2 style="color: #00a32a; font-size: 32px; margin-bottom: 20px;">✓ Thank You!</h2>';
                    msg.innerHTML = '<div style="background: #e7f5ee; border: 2px solid #00a32a; border-radius: 8px; padding: 30px; text-align: center;">' +
                        '<p style="color: #00a32a; font-size: 18px; font-weight: 600; margin: 0 0 15px;">Your sales request has been successfully submitted</p>' +
                        '<p style="color: #333; margin: 0; line-height: 1.6;">We have received your request and will contact you within 2 business days to discuss the next steps.</p>' +
                        '<p style="color: #666; margin: 20px 0 0; font-size: 14px;">You will receive a confirmation email at: <strong>' + val('email') + '</strong></p>' +
                        '</div>';
                    window.scrollTo({ top: 0, behavior: 'smooth' });
                } else {
                    msg.innerHTML = '<div style="background: #fcf0f1; border: 2px solid #b3392c; border-radius: 8px; padding: 20px; text-align: center;">' +
                        '<p style="color: #b3392c; margin: 0;">' + (res.data.message || 'Error sending.') + '</p>' +
                        '</div>';
                    submitBtn.disabled = false;
                    submitBtn.textContent = 'Submit for Evaluation';
                }
            })
            .catch(function () {
                var msg = document.getElementById('noah-wizard-msg');
                msg.innerHTML = '<div style="background: #fcf0f1; border: 2px solid #b3392c; border-radius: 8px; padding: 20px; text-align: center;">' +
                    '<p style="color: #b3392c; margin: 0;">Connection error. Please try again.</p>' +
                    '</div>';
                submitBtn.disabled = false;
                submitBtn.textContent = 'Submit for Evaluation';
            });
        });

        updateProgress();
    })();
    </script>
    <?php
    return ob_get_clean();
});

/* ==========================================
   8. AJAX SUBMIT — with notifications & phone fix
   ========================================== */
add_action('wp_ajax_noah_submit_sell_lead', 'noah_handle_sell_lead');
add_action('wp_ajax_nopriv_noah_submit_sell_lead', 'noah_handle_sell_lead');

if (!function_exists('noah_handle_sell_lead')) {
    function noah_handle_sell_lead() {
        check_ajax_referer('noah_sell_lead_action', 'nonce');
        
        $name = sanitize_text_field($_POST['name'] ?? '');
        $email = sanitize_email($_POST['email'] ?? '');
        
        if (!$name || !is_email($email)) {
            wp_send_json_error(array('message' => 'Please provide name and valid email.'));
        }

        $category     = sanitize_text_field($_POST['item_category'] ?? '');
        $metal        = sanitize_text_field($_POST['metal_type'] ?? '');
        $fineness     = sanitize_text_field($_POST['fineness'] ?? '');
        $weight       = sanitize_text_field($_POST['weight'] ?? '');
        $condition    = sanitize_text_field($_POST['condition'] ?? '');
        $brand        = sanitize_text_field($_POST['brand'] ?? '');
        $desc         = sanitize_textarea_field($_POST['description'] ?? '');
        $phone_country = sanitize_text_field($_POST['phone_country'] ?? '+43');
        $phone        = sanitize_text_field($_POST['phone'] ?? '');
        $phone_full   = $phone_country . ' ' . $phone;
        $country      = sanitize_text_field($_POST['country'] ?? '');
        $city         = sanitize_text_field($_POST['city'] ?? '');
        $address      = sanitize_text_field($_POST['address'] ?? '');
        $contact_pref = sanitize_text_field($_POST['contact_pref'] ?? 'Email');
        $message      = sanitize_textarea_field($_POST['message'] ?? '');

        $post_id = wp_insert_post(array(
            'post_type'   => 'noah_sell_lead',
            'post_title'  => $name . ' — ' . $category . ' (' . $metal . ')',
            'post_status' => 'publish',
        ));

        if (is_wp_error($post_id)) {
            wp_send_json_error(array('message' => 'Error saving request.'));
        }

        // Save all data to post meta
        update_post_meta($post_id, '_noah_lead_name', $name);
        update_post_meta($post_id, '_noah_lead_email', $email);
        update_post_meta($post_id, '_noah_lead_phone', $phone_full); // Phone saved correctly
        update_post_meta($post_id, '_noah_lead_category', $category);
        update_post_meta($post_id, '_noah_lead_metal', $metal);
        update_post_meta($post_id, '_noah_lead_fineness', $fineness);
        update_post_meta($post_id, '_noah_lead_weight', $weight);
        update_post_meta($post_id, '_noah_lead_condition', $condition);
        update_post_meta($post_id, '_noah_lead_brand', $brand);
        update_post_meta($post_id, '_noah_lead_description', $desc);
        update_post_meta($post_id, '_noah_lead_country', $country);
        update_post_meta($post_id, '_noah_lead_city', $city);
        update_post_meta($post_id, '_noah_lead_address', $address);
        update_post_meta($post_id, '_noah_lead_contact_pref', $contact_pref);
        update_post_meta($post_id, '_noah_lead_message', $message);
        update_post_meta($post_id, '_noah_lead_status', 'new');

        // Handle file uploads
        if (!function_exists('media_handle_upload')) {
            require_once ABSPATH . 'wp-admin/includes/image.php';
            require_once ABSPATH . 'wp-admin/includes/file.php';
            require_once ABSPATH . 'wp-admin/includes/media.php';
        }

        $upload_group = function ($field) use ($post_id) {
            $ids = array();
            if (!empty($_FILES[$field]) && is_array($_FILES[$field]['name'])) {
                foreach ($_FILES[$field]['name'] as $i => $filename) {
                    if (empty($filename)) continue;
                    $_FILES['noah_temp_upload'] = array(
                        'name'     => $_FILES[$field]['name'][$i],
                        'type'     => $_FILES[$field]['type'][$i],
                        'tmp_name' => $_FILES[$field]['tmp_name'][$i],
                        'error'    => $_FILES[$field]['error'][$i],
                        'size'     => $_FILES[$field]['size'][$i],
                    );
                    $attach_id = media_handle_upload('noah_temp_upload', $post_id);
                    if (!is_wp_error($attach_id)) {
                        $ids[] = $attach_id;
                    }
                }
            }
            return $ids;
        };

        $image_ids = $upload_group('photos');
        $doc_ids   = $upload_group('documents');
        
        if (!empty($image_ids)) {
            update_post_meta($post_id, '_noah_lead_images', $image_ids);
        }
        if (!empty($doc_ids)) {
            update_post_meta($post_id, '_noah_lead_documents', $doc_ids);
        }

        // 1. Create In-Dashboard Notification (Fixed)
        $user = get_user_by('email', $email);
        if ($user) {
            noah_create_notification(
                $user->ID, 
                'seller', 
                'Sales Request Submitted', 
                "Your sales request for {$category} has been submitted successfully.", 
                home_url('/my-account/noah-selling-requests/')
            );
        }

        // 2. Send Admin Email
        noah_send_admin_notification($post_id, $name, $category);

        // 3. Send User Confirmation Email
        $subject = 'NOAH Edelmetalle - Your Sales Request Successfully Submitted';
        $user_message = "Dear {$name},\n\n";
        $user_message .= "Thank you for your sales request to NOAH Edelmetalle.\n\n";
        $user_message .= "We have received your request and will process it within 2 business days.\n\n";
        $user_message .= "Your information:\n";
        $user_message .= "Product: {$category}\n";
        $user_message .= "Metal: {$metal}\n";
        $user_message .= "Weight: {$weight}g\n";
        $user_message .= "Condition: {$condition}\n\n";
        $user_message .= "Our team will contact you via {$contact_pref} as requested.\n\n";
        $user_message .= "Best regards,\nYour NOAH Team\n\n";
        $user_message .= "NOAH Edelmetalle\nGraben 14, 1010 Vienna\nTel: +43 1 2345678\ninfo@noah-edelmetalle.at";

        wp_mail($email, $subject, $user_message);

        wp_send_json_success();
    }
}
/* ==========================================
   9. SELLER DASHBOARD SHORTCODE - FIXED
   ========================================== */
add_shortcode('noah_seller_dashboard', function() {
    if (!is_user_logged_in()) {
        return '<div class="noah-login-required" style="padding: 40px; text-align: center; background: #f8f9fa; border-radius: 8px;">
            <h3 style="color: #1B2430; margin-bottom: 20px;">Please Log In</h3>
            <p style="color: #666; margin-bottom: 20px;">You must be logged in to view your sales requests.</p>
            <a href="' . wp_login_url(get_permalink()) . '" class="button" style="background: #C9A467; color: #fff; padding: 12px 24px; text-decoration: none; border-radius: 4px; display: inline-block;">Log In</a>
        </div>';
    }
    
    $current_user = wp_get_current_user();
    $email = $current_user->user_email;
    $user_id = $current_user->ID;
    
    // Get all leads for this user by email
    $leads = get_posts(array(
        'post_type' => 'noah_sell_lead',
        'posts_per_page' => -1,
        'meta_query' => array(
            array(
                'key' => '_noah_lead_email',
                'value' => $email,
                'compare' => '='
            )
        ),
        'orderby' => 'date',
        'order' => 'DESC'
    ));
    
    // Also check for consignments linked to this user
    $consignments = get_posts(array(
        'post_type' => 'noah_consignment',
        'posts_per_page' => -1,
        'meta_query' => array(
            'relation' => 'OR',
            array(
                'key' => '_noah_owner_user_id',
                'value' => $user_id,
                'compare' => '='
            ),
            array(
                'key' => '_noah_owner_email',
                'value' => $email,
                'compare' => '='
            )
        ),
        'orderby' => 'date',
        'order' => 'DESC'
    ));
    
    ob_start();
    ?>
    <div class="noah-seller-dashboard">
        <h2>My Sales Requests</h2>
        
        <?php if (empty($leads) && empty($consignments)) : ?>
            <div class="noah-empty-state" style="padding: 40px; text-align: center; background: #f8f9fa; border-radius: 8px; border: 2px dashed #D8CFBC;">
                <p style="color: #666; font-size: 16px; margin: 0;">You haven't submitted any sales requests yet.</p>
                <p style="color: #8A8578; margin: 10px 0 20px;">Start by submitting your first item to sell.</p>
                <a href="/sell-with-noah" class="button" style="background: #C9A467; color: #fff; padding: 12px 24px; text-decoration: none; border-radius: 4px; display: inline-block; font-weight: 600;">Submit Sales Request</a>
            </div>
        <?php else : ?>
            
            <?php if (!empty($leads)) : ?>
            <div class="noah-section" style="margin-bottom: 40px;">
                <h3 style="color: #1B2430; margin-bottom: 20px; font-size: 20px;">Sales Requests</h3>
                <div class="noah-leads-table">
                    <table style="width: 100%; border-collapse: collapse; background: #fff; border-radius: 8px; overflow: hidden; box-shadow: 0 2px 8px rgba(0,0,0,0.1);">
                        <thead>
                            <tr style="background: #C9A467; color: #fff;">
                                <th style="padding: 16px 20px; text-align: left; font-weight: 600; text-transform: uppercase; font-size: 13px;">Date</th>
                                <th style="padding: 16px 20px; text-align: left; font-weight: 600; text-transform: uppercase; font-size: 13px;">Product</th>
                                <th style="padding: 16px 20px; text-align: left; font-weight: 600; text-transform: uppercase; font-size: 13px;">Status</th>
                                <th style="padding: 16px 20px; text-align: left; font-weight: 600; text-transform: uppercase; font-size: 13px;">Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($leads as $lead) : 
                                $status = get_post_meta($lead->ID, '_noah_lead_status', true) ?: 'new';
                                $category = get_post_meta($lead->ID, '_noah_lead_category', true);
                                $metal = get_post_meta($lead->ID, '_noah_lead_metal', true);
                                
                                $status_labels = array(
                                    'new' => array('🆕 New', '#e3f2fd', '#1976d2'),
                                    'contacted' => array(' Contacted', '#fff3e0', '#f57c00'),
                                    'evaluation' => array('🔍 Under Review', '#f3e5f5', '#7b1fa2'),
                                    'agreement' => array(' Agreement', '#e8f5e9', '#388e3c'),
                                    'received' => array('📦 At NOAH', '#fff8e1', '#f9a825'),
                                    'published' => array('🌐 Published', '#e0f7fa', '#00acc1'),
                                    'sold' => array('✅ Sold', '#c8e6c9', '#2e7d32'),
                                    'picked_up' => array('🎁 Picked Up', '#f3e5f5', '#7b1fa2'),
                                    'closed' => array('✔️ Completed', '#cfd8dc', '#546e7a'),
                                    'completed' => array('✔️ Completed', '#cfd8dc', '#546e7a')
                                );
                                
                                $status_info = $status_labels[$status] ?? array(ucfirst($status), '#f5f5f5', '#666');
                            ?>
                                <tr style="border-bottom: 1px solid #eee;">
                                    <td style="padding: 16px 20px;"><?php echo date('M d, Y', strtotime($lead->post_date)); ?></td>
                                    <td style="padding: 16px 20px;">
                                        <strong style="color: #1B2430;"><?php echo esc_html($category); ?></strong>
                                        <?php if ($metal) : ?>
                                            <br><small style="color: #8A8578;"><?php echo esc_html($metal); ?></small>
                                        <?php endif; ?>
                                    </td>
                                    <td style="padding: 16px 20px;">
                                        <span class="status-badge" style="display: inline-block; padding: 6px 12px; border-radius: 4px; font-size: 13px; font-weight: 600; background: <?php echo $status_info[1]; ?>; color: <?php echo $status_info[2]; ?>;">
                                            <?php echo $status_info[0]; ?>
                                        </span>
                                    </td>
                                    <td style="padding: 16px 20px;">
                                        <a href="<?php echo admin_url('admin-ajax.php?action=noah_view_lead&lead_id=' . $lead->ID); ?>" class="button" style="background: #C9A467; color: #fff; padding: 8px 16px; border-radius: 4px; text-decoration: none; display: inline-block; font-size: 13px;">View Details</a>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            </div>
            <?php endif; ?>
            
            <?php if (!empty($consignments)) : ?>
            <div class="noah-section">
                <h3 style="color: #1B2430; margin-bottom: 20px; font-size: 20px;">Consigned Items</h3>
                <div class="noah-leads-table">
                    <table style="width: 100%; border-collapse: collapse; background: #fff; border-radius: 8px; overflow: hidden; box-shadow: 0 2px 8px rgba(0,0,0,0.1);">
                        <thead>
                            <tr style="background: #C9A467; color: #fff;">
                                <th style="padding: 16px 20px; text-align: left; font-weight: 600; text-transform: uppercase; font-size: 13px;">Item</th>
                                <th style="padding: 16px 20px; text-align: left; font-weight: 600; text-transform: uppercase; font-size: 13px;">Date Received</th>
                                <th style="padding: 16px 20px; text-align: left; font-weight: 600; text-transform: uppercase; font-size: 13px;">Status</th>
                                <th style="padding: 16px 20px; text-align: left; font-weight: 600; text-transform: uppercase; font-size: 13px;">Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($consignments as $consignment) : 
                                $consignment_status = get_post_meta($consignment->ID, '_noah_consignment_status', true) ?: 'received';
                                $payout_status = get_post_meta($consignment->ID, '_noah_payout_status', true) ?: 'pending';
                                
                                $consignment_status_labels = array(
                                    'received' => array(' Received', '#fff8e1', '#f9a825'),
                                    'evaluation' => array('🔍 Evaluation', '#f3e5f5', '#7b1fa2'),
                                    'published' => array('🌐 Published', '#e0f7fa', '#00acc1'),
                                    'sold' => array('✅ Sold', '#c8e6c9', '#2e7d32'),
                                    'picked_up' => array('🎁 Picked Up', '#f3e5f5', '#7b1fa2'),
                                    'completed' => array('✔️ Completed', '#cfd8dc', '#546e7a')
                                );
                                
                                $status_info = $consignment_status_labels[$consignment_status] ?? array(ucfirst($consignment_status), '#f5f5f5', '#666');
                            ?>
                                <tr style="border-bottom: 1px solid #eee;">
                                    <td style="padding: 16px 20px;">
                                        <strong style="color: #1B2430;"><?php echo esc_html($consignment->post_title); ?></strong>
                                    </td>
                                    <td style="padding: 16px 20px;"><?php echo date('M d, Y', strtotime(get_post_meta($consignment->ID, '_noah_date_received', true))); ?></td>
                                    <td style="padding: 16px 20px;">
                                        <span class="status-badge" style="display: inline-block; padding: 6px 12px; border-radius: 4px; font-size: 13px; font-weight: 600; background: <?php echo $status_info[1]; ?>; color: <?php echo $status_info[2]; ?>;">
                                            <?php echo $status_info[0]; ?>
                                        </span>
                                        <?php if ($payout_status) : ?>
                                            <br><small style="color: #8A8578;">Payout: <?php echo ucfirst($payout_status); ?></small>
                                        <?php endif; ?>
                                    </td>
                                    <td style="padding: 16px 20px;">
                                        <a href="<?php echo get_permalink($consignment->ID); ?>" class="button" style="background: #C9A467; color: #fff; padding: 8px 16px; border-radius: 4px; text-decoration: none; display: inline-block; font-size: 13px;">View Item</a>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            </div>
            <?php endif; ?>
            
        <?php endif; ?>
    </div>
    <?php
    return ob_get_clean();
});
/* ==========================================
   7. ADMIN META BOX FOR CONSIGNMENTS (FIXES INVISIBLE DATA)
   ========================================== */
add_action('add_meta_boxes', 'noah_register_consignment_meta_box');
function noah_register_consignment_meta_box() {
    add_meta_box(
        'noah_consignment_details',
        'Consignment Details & Payout',
        'noah_consignment_meta_box_callback',
        'noah_consignment',
        'normal',
        'high'
    );
}

function noah_consignment_meta_box_callback($post) {
    wp_nonce_field('noah_consignment_save', 'noah_consignment_nonce');
    
    // Retrieve all saved data
    $owner_name = get_post_meta($post->ID, '_noah_owner_name', true);
    $owner_email = get_post_meta($post->ID, '_noah_owner_email', true);
    $category = get_post_meta($post->ID, '_noah_lead_category', true);
    $metal = get_post_meta($post->ID, '_noah_lead_metal', true);
    $weight = get_post_meta($post->ID, '_noah_lead_weight', true);
    $date_received = get_post_meta($post->ID, '_noah_date_received', true);
    $status = get_post_meta($post->ID, '_noah_consignment_status', true) ?: 'received';
    $payout_status = get_post_meta($post->ID, '_noah_payout_status', true) ?: 'pending';
    $payout_amount = get_post_meta($post->ID, '_noah_payout_amount', true);
    $linked_product = get_post_meta($post->ID, '_linked_product_id', true);

    echo '<div style="display: grid; grid-template-columns: 1fr 1fr; gap: 30px;">';
    
    // Left Column: Read-only Info from Form
    echo '<div style="background: #f9f9f9; padding: 15px; border-radius: 4px; border: 1px solid #ddd;">';
    echo '<h4 style="margin-top:0;">Seller & Item Info</h4>';
    echo '<p><strong>Owner:</strong> ' . esc_html($owner_name) . '<br><small>' . esc_html($owner_email) . '</small></p>';
    echo '<p><strong>Item:</strong> ' . esc_html($category) . ' (' . esc_html($metal) . ', ' . esc_html($weight) . 'g)</p>';
    echo '<p><strong>Date Received:</strong> ' . esc_html($date_received) . '</p>';
    if ($linked_product) {
        echo '<p><strong>Linked Inventory Product:</strong> <a href="' . esc_url(get_edit_post_link($linked_product)) . '" target="_blank">Edit Product #' . $linked_product . '</a></p>';
    }
    echo '</div>';

    // Right Column: Editable Management Fields
    echo '<div>';
    echo '<h4 style="margin-top:0;">Management</h4>';
    
    echo '<p style="margin-bottom: 15px;"><label style="font-weight:600; display:block; margin-bottom:5px;">Consignment Status</label>';
    echo '<select name="noah_consignment_status" style="width:100%;padding:8px;">';
    $statuses = array('received' => 'Received', 'evaluation' => 'Under Evaluation', 'published' => 'Published', 'sold' => 'Sold', 'picked_up' => 'Picked Up', 'returned' => 'Returned');
    foreach ($statuses as $key => $label) {
        echo '<option value="' . $key . '" ' . selected($status, $key, false) . '>' . $label . '</option>';
    }
    echo '</select></p>';

    echo '<p style="margin-bottom: 15px;"><label style="font-weight:600; display:block; margin-bottom:5px;">Payout Status</label>';
    echo '<select name="noah_payout_status" style="width:100%;padding:8px;">';
    $p_statuses = array('pending' => 'Pending', 'approved' => 'Approved', 'paid' => 'Paid');
    foreach ($p_statuses as $key => $label) {
        echo '<option value="' . $key . '" ' . selected($payout_status, $key, false) . '>' . $label . '</option>';
    }
    echo '</select></p>';

    echo '<p style="margin-bottom: 15px;"><label style="font-weight:600; display:block; margin-bottom:5px;">Agreed Payout Amount (€)</label>';
    echo '<input type="number" step="0.01" name="noah_payout_amount" value="' . esc_attr($payout_amount) . '" style="width:100%;padding:8px;"></p>';
    echo '</div>';
    
    echo '</div>';
}

// Save the editable fields when the post is updated
add_action('save_post_noah_consignment', 'noah_save_consignment_meta');
function noah_save_consignment_meta($post_id) {
    if (!isset($_POST['noah_consignment_nonce']) || !wp_verify_nonce($_POST['noah_consignment_nonce'], 'noah_consignment_save')) {
        return;
    }
    if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE) return;
    if (!current_user_can('edit_post', $post_id)) return;

    if (isset($_POST['noah_consignment_status'])) {
        update_post_meta($post_id, '_noah_consignment_status', sanitize_text_field($_POST['noah_consignment_status']));
    }
    if (isset($_POST['noah_payout_status'])) {
        update_post_meta($post_id, '_noah_payout_status', sanitize_text_field($_POST['noah_payout_status']));
    }
    if (isset($_POST['noah_payout_amount'])) {
        update_post_meta($post_id, '_noah_payout_amount', floatval($_POST['noah_payout_amount']));
    }
}
